export const environment = {
  production: false,
  apiBase: 'http://localhost:5264' // same backend URL 
};
